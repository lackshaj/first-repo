public class HardHangman extends AbstractHangman {
    public HardHangman(String secretWord) {
        super(secretWord, 6); // Hard level allows 6 attempts
    }
}