public class EasyHangman extends AbstractHangman {
    public EasyHangman(String secretWord) {
        super(secretWord, 10); // Easy level allows 10 attempts
    }
}