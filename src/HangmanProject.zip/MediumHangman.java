public class MediumHangman extends AbstractHangman {
    public MediumHangman(String secretWord) {
        super(secretWord, 8); // Medium level allows 8 attempts
    }
}